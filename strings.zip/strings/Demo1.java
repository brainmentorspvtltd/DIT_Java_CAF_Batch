class Demo1 {
    public static void main(String[] args) {
        // String maintain String pool
        // String Immutable
        // String object a) String Literal Style b) new String
        String name = "Amit"; // String Literal (String Pool Create)
        String name2 = "Amit";
        System.out.println(name == name2); // reference compare
        System.out.println(name.equals(name2)); // value compare
        System.out.println(name.equalsIgnoreCase(name2)); // value compare case ignore
        System.out.println(name.compareTo(name2));
        System.out.println("amit".compareTo("ajay"));
        String a = "Hello".intern();// Check in a pool String is present or not , if not present so create a new
                                    // string in a pool otherwise assign the older one reference
        a = a + "Ok";
        System.out.println(a);
        String d = new String("Amit");
        System.out.println(d == name); // false
        String e = new String("Ram");
        String f = new String("Shyam").intern();
        String f2 = "Shyam";
        System.out.println(f == f2); // true

        // String a = "Hello";
    }
}