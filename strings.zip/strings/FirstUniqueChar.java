import java.util.HashMap;

public class FirstUniqueChar {
    public static void main(String[] args) {
        String s = "loveleetcode";
        HashMap<Character, Integer> map = new HashMap<>();
        for (int i = 0; i < s.length(); i++) {
            char singleChar = s.charAt(i);
            if (map.get(singleChar) == null) {
                map.put(singleChar, 1);
            } else {
                int value = map.get(singleChar);
                value++;
                map.put(singleChar, value);
            }

        } // Loop Ends O(N)
          // Now Lookup for First Occurance
        for (int i = 0; i < s.length(); i++) {
            char singleChar = s.charAt(i);
            if (map.get(singleChar) == 1) {
                System.out.println(i);
                return;
            }
        }
    }
}
