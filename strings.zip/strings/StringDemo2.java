
public class StringDemo2 {
    public static void main(String[] args) {
        // Mutable (Modify)
        StringBuffer sb2 = new StringBuffer(50);
        // StringBuffer sb = new StringBuffer("Amit"); // 16 + 4 = 20 By Default 16
        // Space Allocate
        // Java 5 onwards
        StringBuilder sb = new StringBuilder("Amit"); // Not synchronized
        System.out.println(sb.capacity());
        System.out.println(sb.length());
        sb.append("qwertyuiopasdfghjk");
        System.out.println(sb.capacity());
        System.out.println(sb.length());
        sb.append("qwertyuiopasdfghjk fgkjdhgkfjdg gjdfhkghdfkjhg gkdfhgkjdfhgj gdkjfhgdkj gdfkhgjh");
        System.out.println(sb.capacity());
        System.out.println(sb.length());
        sb.append("abcd"); // add in last
        System.out.println(sb.capacity());
        System.out.println(sb.length());
        sb.insert(1, "Hi"); // index wise add
        sb.deleteCharAt(1); // single char delete
        sb.delete(2, 5); // multi char delete
        sb.reverse();
        sb.ensureCapacity(1000);
        sb.toString().toUpperCase();
    }
}
