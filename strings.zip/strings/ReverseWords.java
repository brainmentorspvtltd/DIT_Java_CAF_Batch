package strings;

public class ReverseWords {
    public static void main(String[] args) {
        String str = "a good   example";
        // blue is sky the
        String arr[] = str.split(" ");
        StringBuilder sb = new StringBuilder();
        for (int i = arr.length - 1; i >= 0; i--) {
            if (arr[i].trim().length() > 0) {
                sb.append(arr[i] + " ");
            }
        }
        str = sb.toString();
        System.out.println(str.trim());
    }
}
