import java.util.Arrays;

public class StringFunctions {
    public static void main(String[] args) {
        String name = "Amit Srivastava";
        System.out.println(name.length()); // total no of chars
        System.out.println(name.toUpperCase());
        System.out.println(name);
        System.out.println(name.startsWith("Amit")); // true
        System.out.println(name.endsWith("ava"));
        System.out.println(name.contains("mit"));
        System.out.println(name.indexOf("mit"));
        System.out.println(name.lastIndexOf("t"));
        System.out.println(name.substring(1, 3)); // start index , end index -1
        String e[] = name.split(" ");
        System.out.println("First Name " + e[0]);
        System.out.println("Last Name " + e[1]);
        char arr[] = name.toLowerCase().toCharArray(); // string convert into char []
        Arrays.sort(arr);
        for (char singleChar : arr) {
            System.out.println(singleChar);
        }
        char r[] = { 'A', 'n', 'i', 'l' };
        String r2 = new String(r); // char arr convert into string
        byte q[] = "Ajay".getBytes(); // String convert into bytes (Store File or Network)
        // string single char
        char singleChar = "ajay".charAt(3);
        System.out.println(singleChar);
        String t = "Hello";
        t = t.replace('l', 'a');
        System.out.println(t);
    }
}
