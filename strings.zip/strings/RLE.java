public class RLE {
    public static void main(String[] args) {
        String str = "aaaabbbccc";
        // a4b3c3
        // Traverse char by char
        int len = str.length();
        char arr[] = str.toCharArray();

        for (int i = 0; i < len; i++) {
            int freqCount = 1;
            while (i < len - 1 && arr[i] == arr[i + 1]) {
                freqCount++;
                i++;
            }
            System.out.print(arr[i] + "" + freqCount);
        }
        System.out.println();

        // Hint Using Hashing

    }
}
